/*
AC’s have at least (but are not limited to having) the following properties:
AC type:  Passenger or Cargo
AC size:  Small or Large
Passenger AC’s have removal precedence over Cargo AC’s.
Large AC’s of a given type have removal precedence over Small AC’s of the same type.
Earlier enqueued AC’s of a given type and size have precedence over later enqueued AC’s
of the same type and size

Logic = Large Passenger -> Small Passenger -> Large Cargo -> Small Cargo
References:
    https://stackoverflow.com/questions/21626439/how-to-implement-the-java-comparable-interface
    https://devwithus.com/java-priority-queue/
    https://stackoverflow.com/questions/4389500/how-can-i-find-the-amount-of-seconds-passed-from-the-midnight-with-java
    https://howtodoinjava.com/java/collections/java-priorityqueue/
    https://www.freecodecamp.org/news/priority-queue-implementation-in-java/
*/


import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoField;


public class AirCraft implements Comparable<AirCraft> {
    private final LocalTime aircraftID;
    private final String type;
    private final String size;
    ZoneId z = ZoneId.of("EST5EDT");
    ZonedDateTime zdt = ZonedDateTime.now(z);
    long nanoOfDay = zdt.getLong(ChronoField.NANO_OF_DAY);

    public  AirCraft(String type, String size) {
        this.aircraftID = LocalTime.ofNanoOfDay(nanoOfDay);
        this.type = type;
        this.size = size;
    }

    public String getType() {
        return type;
    }
    public String getSize() {
        return size;
    }
    public LocalTime getAircraftID() {
        return aircraftID;
    }

    public int getAirCraft() {
        int aircraftStatus = 0;
        if(this.type.equalsIgnoreCase("passenger") && this.size.equalsIgnoreCase("large")){
            aircraftStatus = 3;
        } else if(this.type.equalsIgnoreCase("passenger") && this.size.equalsIgnoreCase("small")) {
            aircraftStatus = 2;
        } else if (this.type.equalsIgnoreCase("cargo") && this.size.equalsIgnoreCase("large")) {
            aircraftStatus = 1;
        }
        return aircraftStatus;
    }

    @Override
    public int compareTo(AirCraft o) {
        if(this.getAirCraft() == o.getAirCraft() && this.getAircraftID() == o.getAircraftID()){
            return -1;
        } else if (this.getAirCraft() < o.getAirCraft()) {
            return 1;
        } else {
            return 0;
        }
    }
}
