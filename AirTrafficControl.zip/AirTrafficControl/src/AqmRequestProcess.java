// Referenced https://stackoverflow.com/questions/42596774/keep-process-running-until-user-exit to create this Class


import java.util.InputMismatchException;
import java.util.PriorityQueue;
import java.util.Scanner;

public class AqmRequestProcess implements Runnable{
    private boolean running = false;
    private boolean exit = false;
    PriorityQueue<AirCraft> queueOfAirCrafts = new PriorityQueue<AirCraft>();
    @Override
    public void run() {
        
        running = true;
        Scanner sc = new Scanner(System.in);
        System.out.println("Initiating Advanced Air Traffic Control Queue Manager");
        System.out.println("Pick an Option: (enqueue, dequeue, exit)");
        while(sc.hasNext()) {
            String option = sc.next();
            if(option.equalsIgnoreCase("enqueue") || option.equalsIgnoreCase("e")) {
                enqueue();
            } else if (option.equalsIgnoreCase("dequeue") || option.equalsIgnoreCase("d")) {
                dequeue();
            } else if (option.equalsIgnoreCase("exit")) {
                exit();
                timeToExit();
            } else {
                System.out.println("Please pick an option listed above (enqueue, dequeue, OR exit)");
            }

        }
    }

    public boolean isRunning() {
        return running;
    }
    public boolean shouldExit() {
        return exit;
    }
    public void timeToExit() {
        exit = true;
        System.exit(0);
    }
    public void enqueue(){
        Scanner ts = new Scanner(System.in);
        boolean validData = false;
        do{
            System.out.print("What type of AirCraft is it? (Passenger or Cargo) ");
            try{
                String type = ts.next();
                if(type.equalsIgnoreCase("passenger") || type.equalsIgnoreCase("cargo")){
                    System.out.print("What size AirCraft is it? (Large or Small) ");
                    String size = ts.next();
                    if(size.equalsIgnoreCase("large") || size.equalsIgnoreCase("small")){
                        queueOfAirCrafts.add(new AirCraft(type, size));
                        validData = true;
                    }
                }
            } catch(InputMismatchException e) {
                System.out.println("Input has to match what was suggested above (not case sensitive)");
            }
        } while(!validData);
        System.out.println("Pick an Option: (enqueue, dequeue, exit)");
    }

    public void dequeue(){
        if(queueOfAirCrafts.isEmpty()){
            System.out.println("No AirCrafts in queue");
            System.out.println("Pick an Option: (enqueue, dequeue, exit)");
        } else {
            AirCraft airCraft = queueOfAirCrafts.poll();
            assert airCraft != null;
            System.out.println("AirCraft is cleared to fly: " + airCraft.getType() + " " + airCraft.getSize() + " " + airCraft.getAircraftID());
            System.out.println("Pick an Option: (enqueue, dequeue, exit)");
        }
    }

    public void exit(){
        if(!queueOfAirCrafts.isEmpty()){
            do{
                AirCraft airCrafts = queueOfAirCrafts.poll();
                String sbG = "Following AirCrafts are grounded for the night: " + airCrafts.getType() + " " + airCrafts.getSize()  + " " +
                        airCrafts.getAircraftID();
                System.out.println(sbG);
            } while(!queueOfAirCrafts.isEmpty());

        } else {
            System.out.println("AirCraft Queue Manager Shutting Down");
            timeToExit();
        }
    }
}
