import java.util.Scanner;

public class InitialSequence {
    public static void initialSequence() {
        Scanner sc = new Scanner(System.in);
        boolean io = false;
        do {
            System.out.println("Initiate Systems? y/n");
            String i = sc.next();
            if (i.equalsIgnoreCase("y")) {
                io = true;
                try {
                    AqmRequestProcess aqm_request_process = new AqmRequestProcess();
                    while (true) {
                        Thread.sleep(1000);
                        if (!aqm_request_process.isRunning()) {
                            new Thread(aqm_request_process).start();
                        } else if (aqm_request_process.shouldExit()) {
                            throw new InterruptedException();
                        }
                    }
                } catch (InterruptedException e) {
                    System.out.println("Program is shutting down");
                }
            } else if (i.equalsIgnoreCase("n")) {
                System.out.println("Initiation Cancelled");
                System.exit(0);
            } else {
                System.out.println("Either pick y or n");
                io = false;
            }
        } while (!io);
    }
}
